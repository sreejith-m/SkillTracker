import { SafeResourceUrl } from "@angular/platform-browser";
import { AssociateSkillEntity } from "./AssociateSkillEntity";

export class AssociateModel {
    Pic: SafeResourceUrl
    Status: number
    Name: string
    ID: number
    AssociateID:number
    Email: string
    Mobile: number
    Skills: AssociateSkillEntity[]
    Gender: string
    Level: number
    Remark: string
    Strength: string
    Weakness: string

    constructor(
        picture: string,
        status: number,
        name: string,
        id: number,
        AssociateID:number,
        email: string,
        mobile: number,
        Skills: AssociateSkillEntity[],
        gender: string,
        remark: string,
        strength: string,
        weakness: string
    ) {
        this.Pic = picture;
        this.Status = status;
        this.Name = name;
        this.ID = id;
        this.AssociateID = AssociateID;
        this.Email = email;
        this.Mobile = mobile;
        this.Skills = Skills;
        this.Gender = gender;
        this.Remark = remark;
        this.Strength = strength;
        this.Weakness = weakness;
    }
}