import { SafeResourceUrl } from "@angular/platform-browser";
import { Skill } from "./SkillEntity";

export class AssociateSkillEntity {
    AssociateSkillID: number
    AssociateID: number
    Rating: number
    Sk:Skill
    
    constructor(
        AssociateSkillID: number,
        AssociateID: number,
        Rating: number,
        Sk:Skill

    ) 
    {
        this.AssociateID = AssociateID;
        this.AssociateSkillID = AssociateSkillID;
        this.Rating = Rating;
        this.Sk = Sk;  
    }
}