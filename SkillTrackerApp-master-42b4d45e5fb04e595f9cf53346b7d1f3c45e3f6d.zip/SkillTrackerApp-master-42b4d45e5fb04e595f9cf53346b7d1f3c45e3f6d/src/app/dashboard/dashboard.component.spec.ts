import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';
import { DataTableModule } from 'primeng/datatable';
import { GrowlModule } from 'primeng/growl';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { AssociateService } from '../services/associate.service';
import { Interceptor } from '../app.interceptor';
import { CommsService } from '../services/comm.service';
import { SkillService } from '../services/skill.service';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      imports: [ 
        DataTableModule,
        GrowlModule,
        HttpClientModule,
        ReactiveFormsModule,
        RouterTestingModule,
        ButtonModule,
        FormsModule,
        ConfirmDialogModule,
        DialogModule,
        BrowserAnimationsModule
      ],
      providers: [
        ConfirmationService,
        AssociateService,
        CommsService,
        SkillService, {
          provide: HTTP_INTERCEPTORS,
          useClass: Interceptor,
          multi: true
      }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('Dashboard Component should create', () => {
    expect(component).toBeTruthy();
  });

  // // it('On Initialization associate list must be populated', async(() => {
 
  // //   expect(component.associateList.length).toBeGreaterThanOrEqual(0);
  // // }));

  // it('On Intitialization dashboard data must be populated', async(() => {
  //   expect(component.skillDashData.length).toBeGreaterThanOrEqual(0);
  // }));

  // it('On Edit Click, route the user to associate component', async(() => {
    
  // }));
});
