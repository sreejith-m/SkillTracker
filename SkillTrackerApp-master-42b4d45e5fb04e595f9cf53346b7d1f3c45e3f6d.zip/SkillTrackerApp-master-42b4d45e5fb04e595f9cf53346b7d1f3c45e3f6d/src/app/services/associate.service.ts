import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { Skill } from '../entities/SkillEntity';
import { ImageModel } from '../entities/ImageModel';
import { AssociateModel } from '../entities/AssociateModel';
import { Status } from '../entities/StatusEntity';

@Injectable()
export class AssociateService {
  constructor(private http: HttpClient) { }

  uploadFile(image: ImageModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/imageupload", image);
  }
  addAssociateSubmit(associateFormObj: AssociateModel): Observable<Status> {
    console.log(associateFormObj);
    return this.http.post<Status>(environment.apiUrl + "/api/addUpdateAssociate", associateFormObj);
  }

  getAssociateData(): Observable<AssociateModel[]> {
    return this.http.get<AssociateModel[]>(environment.apiUrl + "/api/getAllAssociates");
  }
  getAssociateSkillData(id): Observable<AssociateModel> {
    return this.http.get<AssociateModel>(environment.apiUrl + "/api/getAssociateSkills?assoId="+id);
  }

  deleteAssociate(associateFormObj: AssociateModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/deleteAssociate", associateFormObj);
  }

  updateAssociateSubmit(associateFormObj: AssociateModel): Observable<any> {
    debugger;
    return this.http.post<any>(environment.apiUrl + "/api/addUpdateAssociate", associateFormObj);
  }

  checkAssociateId(associateFormObj: AssociateModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/checkid", associateFormObj);
  }

}
