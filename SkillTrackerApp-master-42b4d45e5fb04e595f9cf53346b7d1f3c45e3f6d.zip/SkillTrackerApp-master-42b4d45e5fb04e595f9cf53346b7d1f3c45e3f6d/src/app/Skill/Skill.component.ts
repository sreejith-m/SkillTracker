import { Component, OnInit } from '@angular/core';
import { Message, ConfirmationService } from 'primeng/api';
import { SkillService } from '../services/skill.service';
import { Skill } from '../entities/SkillEntity';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Status } from '../entities/StatusEntity';

@Component({
  selector: 'app-addskill',
  templateUrl: './Skill.component.html',
  styleUrls: ['./Skill.component.css']
})
export class SkillComponent implements OnInit {
  numbers: number[] = [];
  display: boolean = false; 
  editSkillObj: Skill;
  addSkillObj: Skill;
  skillsList: Skill[] = null;
  msg: Message[] = [];
  addSkillName: string = '';
  addSkillForm: FormGroup;

  constructor(
    private confirmationService: ConfirmationService,
    private skillService: SkillService,
    private formBuilder: FormBuilder
  ) {

    // skillslist
    this.refreshSkillsList();

    // form init
    this.onFormInit();
  }

  ngOnInit() {
  }

  onFormInit() {
    this.addSkillForm = this.formBuilder.group({
      skillNameControl: [null]
    });
  }

  refreshSkillsList() {
    this.skillsList = [];
    this.skillService.getSkillsList().subscribe(data => {
      this.skillsList = data;
    });
  }

  deleteSkill(skill: Skill) {
    this.confirmationService.confirm({
      message: 'Do you want to delete ' + skill.SkillName,
      header: 'Delete',
      key: 'del',
      icon: 'fa fa-trash',
      accept: () => {
        this.skillService.deleteSkill(skill).subscribe(data => {
          if (data.ActionStatus === "Success") {
          this.showMessage(true, "Skill Deleted!");
          this.refreshSkillsList();
          }
        });
      },
      reject: () => {

      }
    });
  }

  editSkill(skill: Skill) {
    this.display = true;
    this.editSkillObj =   JSON.parse(JSON.stringify(skill));
  }

  editSkillName() {
    this.skillService.editSkill(this.editSkillObj).subscribe(data => {
      if (data.ActionStatus === "Success") {
        this.display = false;
        this.editSkillObj = null;
        this.showMessage(true, "Skill Updated!");
        this.refreshSkillsList();
      }
    });
  }

  showMessage(status: boolean, message: string) {
    this.msg = [];
    if (status === true) {
        this.msg.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.msg.push({ severity: 'error', summary: "Error", detail: message });
    }
  }
  
  AddSkill() {
    this.addSkillObj = { SkillName: this.addSkillForm.get('skillNameControl').value, SkillID: null } ;

    this.skillService.addSkill(this.addSkillObj).subscribe(data => {
      
      if (data.ActionStatus === "Success") 
      {
        this.showMessage(true, "Skill Added!");
        this.refreshSkillsList();
      }
    });
  }
  cancelSkillUpdate()
  {
    this.display = false;
  }


}
