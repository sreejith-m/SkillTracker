import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ChartData } from '../entities/ChartData';
import { ActivatedRoute, Router } from '@angular/router'; 
import { CommsService } from '../services/comm.service';
import { AssociateService } from '../services/associate.service';
import { AssociateModel } from '../entities/AssociateModel';
import { DomSanitizer } from '@angular/platform-browser';
import { Message, ConfirmationService } from 'primeng/api';
import { SkillService } from '../services/skill.service';
import { DashboardDataModel } from '../entities/DashboardDataModel';
import { ChartSkills } from '../entities/ChartSkills';
import { RouterModule, Routes } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('mainScreen') elementView: ElementRef;
  
  associateList: AssociateModel[];
  associateImg: any;
  widthExp = 500;
  chart: ChartData[] = [];
  message: Message[] = [];
  dashData: DashboardDataModel = null;
  skillDashData: ChartSkills[] = [];
  graphColors:string[];
   

  constructor(
    private elementRef: ElementRef,
    private route: ActivatedRoute,
    private router: Router,
    private comm: CommsService,
    private associateService: AssociateService,
    private _sanitizer: DomSanitizer,
    private confirmationService: ConfirmationService,
    private skillService: SkillService
  ) {
    this.getDashboardData();
    this.tableInit();
  }

  ngOnInit() {
    this.graphColors=["#F44336","#E91E63","#9C27B0","#673AB7","#3F51B5","#2196F3","#03A9F4","#00BCD4","#009688","#4CAF50","#8BC34A","#CDDC39","#FFEB3B","#FFC107","#FF9800","#FF5722","#795548","#9E9E9E","#607D8B","#00ACC1","#7CB342","#F06292"];
  }

  tableInit() {
    this.associateService.getAssociateData().subscribe(data => {
      this.associateList = data;
    });
  }

  onEditClick(associateObj) {
    this.comm.storage = associateObj;
    this.router.navigate(['/editassociate',associateObj.AssociateID]);    
  } 

  onViewClick(associateObj) {
    this.comm.viewStorage = associateObj;
    console.log('from view click');
    console.log(associateObj);
    this.router.navigate(['/editassociate',associateObj.AssociateID]);  
  }

  deleteAssociate(associateObj) {
    this.confirmationService.confirm({
      message: 'Do you want to delete ' + associateObj.Name + ' ?',
      header: 'Delete',
      key: 'del',
      icon: 'fa fa-trash',
      accept: () => {
        this.associateService.deleteAssociate(associateObj).subscribe(data => {
          if (data.ActionStatus == 'Success') {
            this.showMessage(true, "Associate Deleted !");
            this.tableInit();
          } else {
            this.showMessage(false, "Error");
          }
        });
      },
      reject: () => {

      }
    });
  }

  showMessage(status: boolean, message: string) {
    this.message = [];
    if (status === true) {
        this.message.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.message.push({ severity: 'error', summary: "Error", detail: message });
    }
  }

  getDashboardData() {
    this.skillService.getDashboardData().subscribe(data => {
     this.dashData = data.SummaryBlocks;
      this.skillDashData = data.Chart;
    });
  }
}
