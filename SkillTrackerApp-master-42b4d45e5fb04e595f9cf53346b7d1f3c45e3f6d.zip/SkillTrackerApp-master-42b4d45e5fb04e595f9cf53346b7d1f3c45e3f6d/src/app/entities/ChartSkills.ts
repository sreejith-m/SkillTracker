export interface ChartSkills {
    Title: string,
    Percentage : string,
    
}
