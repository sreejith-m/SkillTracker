import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/materialize';
import 'rxjs/add/operator/dematerialize';
import { Injectable } from '@angular/core';
import { HttpHandler, HttpInterceptor, HttpRequest, HttpEvent, HttpResponse, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class Interceptor implements HttpInterceptor {

    constructor() { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        return Observable.of(null).mergeMap(() => {
          
            if (request.url.endsWith('api/getAllSkills') && request.method === 'GET') {

                
                request = request.clone({url: 'assets/mockData/skillsList-data.json',method:"GET"});                
            }

            if (request.url.endsWith('api/skill/edit') && request.method === 'POST') {

                request = request.clone({url: 'assets/mockData/editSkill-data.json',method:"GET"});
            }
            if (request.url.endsWith('api/associate/getall') && request.method === 'GET') {

                request = request.clone({url: 'assets/mockData/associateList-data.json',method:"GET"});
            }

            if (request.url.endsWith('api/skill/dashboard') && request.method === 'GET') {

                request = request.clone({url: 'assets/mockData/dash-data.json',method:"GET"});
            }
            if (request.url.endsWith('api/addUpdateSkills') && request.method === 'POST') {

                request = request.clone({url: 'assets/mockData/success.json',method:"GET"});
            }
            // if (request.url.endsWith('api/getAllTasks') && request.method === 'GET') {

            //     request = request.clone({url: 'assets/task-list.json',method:"GET"});
            // }if (request.url.endsWith('api/getAllParentTasks') && request.method === 'GET') {

            //     request = request.clone({url: 'assets/parent-task.json',method:"GET"});
            // }
            // if (request.url.endsWith('api/updateTask') && request.method === 'POST') {

            //     request = request.clone({url: 'assets/task-updated.json',method:"GET"});
            // }
            return next.handle(request);

        }).materialize().delay(5).dematerialize();
    }

}

export let fakeService = {
    provide: HTTP_INTERCEPTORS,
    useClass: Interceptor,
    multi: true
};

