import { ChartSkills } from "./ChartSkills";

export interface DashboardDataModel {
    Count,Title:string;
}
