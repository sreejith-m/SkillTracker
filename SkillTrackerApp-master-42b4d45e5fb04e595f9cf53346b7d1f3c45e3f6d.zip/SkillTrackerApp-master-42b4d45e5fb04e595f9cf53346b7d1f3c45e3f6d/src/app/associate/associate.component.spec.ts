import { async, ComponentFixture, TestBed } from '@angular/core/testing';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SliderModule } from 'primeng/slider';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GrowlModule } from 'primeng/growl';
import { ButtonModule } from 'primeng/button';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { Interceptor } from '../app.interceptor';
import { CommsService } from '../services/comm.service';
import { SkillService } from '../services/skill.service';
import { AssociateService } from '../services/associate.service';
import { AssociateComponent } from './associate.component';

describe('EmployeeComponent', () => {
  let component: AssociateComponent;
  let fixture: ComponentFixture<AssociateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociateComponent ],
      imports: [
        FormsModule,
        SliderModule,
        ConfirmDialogModule,
        DialogModule,
        BrowserAnimationsModule,
        GrowlModule,
        ReactiveFormsModule,
        ButtonModule,
        RouterTestingModule,
        SliderModule,
        HttpClientModule
      ],
      providers: [
        ConfirmationService, {
          provide: HTTP_INTERCEPTORS,
          useClass: Interceptor,
          multi: true
      }, CommsService, SkillService, AssociateService
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('show message', () => {
    component.showMessage(true,"test");
    component.onReset();
    expect(component.message.length).toBeGreaterThanOrEqual(0);
  })


});
