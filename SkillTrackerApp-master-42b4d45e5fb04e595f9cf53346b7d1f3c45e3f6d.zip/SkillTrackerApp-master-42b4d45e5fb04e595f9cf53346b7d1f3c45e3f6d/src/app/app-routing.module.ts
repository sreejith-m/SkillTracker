import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SkillComponent } from './Skill/Skill.component';
import { AssociateComponent } from './associate/associate.component';



const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: DashboardComponent },
  { path: 'addskill', component: SkillComponent },
  { path: 'addassociate', component: AssociateComponent },
  { path: 'editassociate/:id', component: AssociateComponent, data: {} }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}