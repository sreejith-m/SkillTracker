import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { CommsService } from '../services/comm.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormArray } from '@angular/forms/src/model';
import { SkillService } from '../services/skill.service';
import { Skill } from '../entities/SkillEntity';
import { AssociateService } from '../services/associate.service';
import { ImageModel } from '../entities/ImageModel';
import { Observable } from 'rxjs/Observable';
import { AssociateModel } from '../entities/AssociateModel';
import { Message, ConfirmationService } from 'primeng/api';
import { AssociateSkillEntity } from '../entities/AssociateSkillEntity';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-associate',
  templateUrl: './associate.component.html',
  styleUrls: ['./associate.component.css']
})
export class AssociateComponent implements OnInit, OnDestroy {
  @ViewChild('imgFileInput')
  myimgFileInputVariable: any;
  val: number = 23;
  numbers: number[] = [];
  mode: string = 'add';
  public addAssociateForm: FormGroup;
  skillsList: Skill[] = null;
  rawImage: ImageModel = null;
  encodedImage: ImageModel = null;
  associateFormObj: AssociateModel;
  imgPreview: any = null;
  disabledValue: any;
  message: Message[] = [];
  AssoSkillObj: AssociateSkillEntity[] = [];
  associateSkillitem: AssociateSkillEntity;
  url = '../../assets/noimage.png';

  constructor(
    private comm: CommsService,
    private formBuilder: FormBuilder,
    private skillService: SkillService,
    private associateService: AssociateService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    if (this.comm.storage !== null && this.comm.viewStorage == null) {    // Edit Mode
      this.mode = 'edit';
      this.onFormInit();
      this.onFormEditInit(this.comm.storage);
    } else if (this.comm.storage == null && this.comm.viewStorage !== null) {
      // View Mode
      this.mode = 'view';
      this.onFormInit();
      this.onFormEditInit(this.comm.viewStorage);
      this.disabledValue = true;
    } else {     // Add Mode
      this.onFormInit();
    }

  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.comm.storage = null;
    this.comm.viewStorage = null;
  }

  // Initialization of Form - Add Mode
  onFormInit() {
    this.addAssociateForm = this.formBuilder.group({
      PictureControl: [null],
      StatusControl: [null, Validators.required],
      NameControl: [null, Validators.required],
      IDControl: [null, Validators.required],
      EmailControl: [null, Validators.required],
      MobileControl: [null, Validators.required],
      SkillsControl: this.formBuilder.array([]),
      GenderControl: [null, Validators.required],
      LevelControl: [null, Validators.required],
      RemarkControl: [null],
      Strength: [null],
      Weakness: [null],
    });
    this.getSkillsList();

  }

  getSkillsList() {
    this.skillService.getSkillsList().subscribe(data => {
      this.skillsList = data;
      this.patchSkillsList();
    });
  }

  addAssociateSubmit() {
    this.associateFormObj = {
      Pic: this.url,
      Status: this.addAssociateForm.get('StatusControl').value,
      Name: this.addAssociateForm.get('NameControl').value,
      ID: 0,
      AssociateID: Number.parseInt(this.addAssociateForm.get('IDControl').value),
      Email: this.addAssociateForm.get('EmailControl').value,
      Mobile: this.addAssociateForm.get('MobileControl').value,
      Skills: this.addAssociateForm.get('SkillsControl').value,
      Gender: this.addAssociateForm.get('GenderControl').value,
      Level: Number.parseInt(this.addAssociateForm.get('LevelControl').value),
      Remark: this.addAssociateForm.get('RemarkControl').value,
      Strength: this.addAssociateForm.get('Strength').value,
      Weakness: this.addAssociateForm.get('Weakness').value
    }

    // Add Associate 
    if (this.mode == 'add') {

      this.associateFormObj.Skills = [];
      const listObj = [];
      this.addAssociateForm.get('SkillsControl').value.forEach(x => {
        this.associateSkillitem = {
          AssociateSkillID: 0,
          AssociateID: 0,
          Rating: x.skillrating,
          Sk: {
            SkillID: x.skillId,
            SkillName: x.skillName
          }
        }
        this.associateFormObj.Skills.push(this.associateSkillitem);
      });
      this.associateService.addAssociateSubmit(this.associateFormObj).subscribe(data => {
        if (data.ActionStatus == 'Success') {
          this.onReset();
          this.showMessage(true, 'Associate added!');
          this.getSkillsList();
        } else {
          this.showMessage(false, 'Associate Add Failed!');
        }
      });

    }
    // Update Associate 
    else if (this.mode == 'edit') {

      this.associateFormObj.Skills = [];
      const listObj = [];
      debugger;
      this.addAssociateForm.get('SkillsControl').value.forEach(x => {
        this.associateFormObj.Skills.push({
          AssociateID:this.comm.storage.id,
          AssociateSkillID: x.associateSkillId,
          Rating: x.skillrating,
          Sk: x.sk
        });
      });
      this.associateFormObj.Pic=this.url;
      this.associateFormObj.ID=this.comm.storage.id;
      this.associateService.updateAssociateSubmit(this.associateFormObj).subscribe(data => {

        if (data.ActionStatus == 'Success') {
          this.onReset();
          this.showMessage(true, 'Associate Updated!');
          this.getSkillsList();
        } else {
          this.showMessage(false, 'Associate Update Failed!');
        }
      });
    }
    else {
      console.log(this.associateFormObj);
    }

  }

  patchSkillsList() {
    const formControl = <FormArray>this.addAssociateForm.controls.SkillsControl;

    if (this.mode == 'add') {
      // Add Employee
      const rating = 0;
      this.skillsList.forEach(x => {
        formControl.push(this.patchValues(x.SkillID, x.SkillName, rating))
      });
    }

  }

  // Skill Array Formbuilder
  patchValues(SkillID, SkillName, Rating) {
    return this.formBuilder.group({
      skillId: [SkillID],
      skillName: [SkillName],
      skillrating: [Rating]

    })
  }

  

  onSelectFile(event) {

    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = reader.result;
      }
    }
  }


  // Initialization of Form - Edit Mode
  onFormEditInit(associateObj) {
    let id = this.route.snapshot.paramMap.get('id');
    this.associateService.getAssociateSkillData(associateObj.id).subscribe(data => {
      associateObj = data;
      this.addAssociateForm.patchValue({
        StatusControl: associateObj.Status.toLowerCase(),
        NameControl: associateObj.Name,
        IDControl: associateObj.AssociateID,
        MobileControl: associateObj.Mobile,
        Strength: associateObj.Strength,
        EmailControl: associateObj.Email,
        GenderControl: associateObj.Gender,
        LevelControl: associateObj.Level.toString(),
        RemarkControl: associateObj.Remark,
        Weakness: associateObj.Weakness,
        PictureControl: associateObj.Picture
      });
      this.url = associateObj.Pic;
      debugger;
      let tempSkills = this.addAssociateForm.get('SkillsControl') as FormArray;
      associateObj.Skills.forEach(skill => {
        tempSkills.push(
          this.formBuilder.group({
            skillName: skill.Sk.SkillName,
            skillrating: skill.Rating,
            associateSkillId: skill.AssociateSkillID,
            sk: skill.Sk
          })
        );
      });
      this.addAssociateForm.patchValue({ SkillsControl: tempSkills });
      this.imgPreview = associateObj.Picture;
    });
  }

  showMessage(status: boolean, message: string) {
    this.message = [];
    if (status === true) {
      this.message.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
      this.message.push({ severity: 'error', summary: "Error", detail: message });
    }
  }

  onReset() {
    this.onFormInit();
  }
  onCancel() {
    this.router.navigate(['/home']);   
  }

  editAssociateSubmit() {

  }
}
