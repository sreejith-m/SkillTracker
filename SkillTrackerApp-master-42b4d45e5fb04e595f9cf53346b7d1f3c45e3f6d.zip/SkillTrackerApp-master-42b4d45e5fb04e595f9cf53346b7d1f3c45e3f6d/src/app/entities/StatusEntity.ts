export class Status {
    Message: string
    ActionStatus: string

    constructor(
        Message: string,
        ActionStatus: string
    ) {
        this.Message = Message;
        this.ActionStatus = ActionStatus;
    }
}