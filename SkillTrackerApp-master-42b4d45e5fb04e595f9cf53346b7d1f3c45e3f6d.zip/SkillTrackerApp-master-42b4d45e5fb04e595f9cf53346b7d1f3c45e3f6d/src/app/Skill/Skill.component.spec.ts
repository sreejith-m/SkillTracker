import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';

import { SkillComponent } from './Skill.component';

import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule, FormBuilder  } from '@angular/forms';

import { ConfirmationService } from 'primeng/api';
import { SkillService } from '../services/skill.service';
import { fakeService, Interceptor } from '../app.interceptor';
import { GrowlModule } from 'primeng/growl';
import { AppRoutingModule } from '../app-routing.module';
import { ButtonModule } from 'primeng/button';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { RouterTestingModule } from '@angular/router/testing';
import { AssociateComponent } from '../associate/associate.component';
import { DataTableModule } from 'primeng/datatable';
import { SliderModule } from 'primeng/slider';

describe('SkillComponent', () => {
  let component: SkillComponent;
  let fixture: ComponentFixture<SkillComponent>;
  let httpClient: HttpClient;
  let confirmationService: ConfirmationService;
  let formBuilder: FormBuilder;
  let spy: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillComponent,AssociateComponent,DashboardComponent ],
      imports: [
        ConfirmDialogModule,
        DialogModule,
        BrowserAnimationsModule,
        FormsModule,
        GrowlModule,
        ReactiveFormsModule,
        AppRoutingModule,
        ButtonModule,
        RouterTestingModule,
        DataTableModule,
        SliderModule,
        HttpClientModule
      ],
      providers: [
        ConfirmationService, {
          provide: HTTP_INTERCEPTORS,
          useClass: Interceptor,
          multi: true
      },SkillService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillComponent);
    component = fixture.componentInstance;

  });

  it('After initialization the no of skills list should be zero or more', async(() => {
    expect(component.skillsList.length).toBeGreaterThanOrEqual(0);
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('add skill', async(() => {
    spy  = spyOn(component, 'showMessage').and.returnValue(true);
    component.addSkillForm.patchValue({ skillNameControl: 'BigData' });
    component.AddSkill();
    expect(component.msg.length).toBeGreaterThanOrEqual(0);
  }));

  // it('Push message to growl array on showMessage call()', async(() => {
  //   component.showMessage(true, 'Success');
  //   expect(component.msg.length).toEqual(1);
  // }));

  // it('On Edit click, open the the dialog box and populate the proeprty with the selected skill name', async(() => {
  //   const skill = { SkillID: 1, SkillName: 'Angular' };
  //   component.editSkill(skill);
  //   expect(component.display).toEqual(true);
  //   expect(component.editSkillObj).toEqual(skill);
  // }));

  it('On Successfull Update click, show success message popup', async(() => {
    component.editSkillObj = { SkillID: 1, SkillName: 'Angular' };    
    component.editSkillName();
    expect(component.display).toEqual(false);
  }));
});
