export class ImageModel {
    FileToString: string

    constructor(fileToString: string) {
        this.FileToString = fileToString;
    }
}