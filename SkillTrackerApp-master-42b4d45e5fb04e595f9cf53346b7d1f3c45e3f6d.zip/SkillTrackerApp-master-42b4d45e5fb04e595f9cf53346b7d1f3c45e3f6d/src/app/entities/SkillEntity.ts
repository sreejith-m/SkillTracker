export class Skill {
    SkillID: number
    SkillName: string

    constructor(
        SkillID: number,
        SkillName: string
    ) {
        this.SkillID = SkillID;
        this.SkillName = SkillName;
    }
}