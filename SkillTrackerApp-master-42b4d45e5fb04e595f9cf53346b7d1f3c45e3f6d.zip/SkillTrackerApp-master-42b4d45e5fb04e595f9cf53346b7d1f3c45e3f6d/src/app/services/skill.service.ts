import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { Skill } from '../entities/SkillEntity';
import { Status } from '../entities/StatusEntity';

@Injectable()
export class SkillService {
  constructor(private http: HttpClient) {}

  getSkillsList(): Observable<Skill[]> {   
    return this.http.get<Skill[]>(environment.apiUrl+"/api/getAllSkills"); 
  }

  editSkill(skill: Skill): Observable<Status> {
      console.log(skill);
      return this.http.post<Status>(environment.apiUrl+"/api/addUpdateSkills", skill);
  }

  addSkill(skill: Skill): Observable<Status> {
      return this.http.post<Status>(environment.apiUrl+"/api/addUpdateSkills", skill);
  }

  deleteSkill(skill: Skill): Observable<Status> {
      return this.http.post<Status>(environment.apiUrl+"/api/deleteSkill", skill);
  }

  getDashboardData(): Observable<any> {
      return this.http.get<any>(environment.apiUrl+"/api/getDashBoardChart");
  }

}
